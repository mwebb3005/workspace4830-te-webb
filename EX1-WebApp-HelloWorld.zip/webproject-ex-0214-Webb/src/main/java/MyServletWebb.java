import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.UtilFile;

@WebServlet("/MyServletWebb")
public class MyServletWebb extends HttpServlet {
   private static final long serialVersionUID = 1L;

   public MyServletWebb() {
      super();
   }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) //
         throws ServletException, IOException {
      response.setContentType("text/html");

      
      
      
      String filename = "/WEB-INF/numbers.csv";
      List<String> contents = UtilFile.readFile(getServletContext(), filename);
      String[] maxArray = new String[10];
      for (String iLine : contents) {
         System.out.println(iLine);
      }
      
      for (int i = 0; i < maxArray.length; i++) {
		  maxArray[i] = "0";
      }
      
      int tempVal = 0;
      
      for (int i = 0; i < contents.size(); i++) {
    	  int val = Integer.parseInt(contents.get(i));
    	  if (val % 2 == 0) {
    		  for (int j = maxArray.length-1; j >= 0; j--) {
    			  if (val >= Integer.parseInt(maxArray[j])){
    				  tempVal = Integer.parseInt(maxArray[j]);
    				  maxArray[j] = Integer.toString(val);
    				  val = tempVal;
    			  }
    		  }
    	  }
    	  continue;
      }
      
      String result = "";
      for (int i = 0; i < maxArray.length; i++) {
    	  if (i != 0) {
    		  result = result + ", " + maxArray[i];
    	  }
    	  else {
    		  result = maxArray[i];
    	  }
      }
      
      
      /*
      if (val >= Integer.parseInt(maxArray[j]) || maxArray[j] == null){
		  
	  }
	  else {
		  
	  }
	  */
      
      
      
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
      String title = "Homework 1";
      String docType = "<!doctype html public \"-//w3c//dtd html 4.0 " + "transitional//en\">\n";
      out.println(docType + //
            "<html>\n" + //
            "<head><title>" + title + "</title></head>\n" + //
            "<body bgcolor=\"#f0f0f0\">\n" + //
            "<h2 align=\"center\">" + title + "</h2>\n" + //
            "<ul>\n" + //

            "  <li><b>Top Ten unique even numbers</b>: "
            + "" + result + "\n" + //
            
            "</ul>\n");   
      
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doGet(request, response);
   }
}